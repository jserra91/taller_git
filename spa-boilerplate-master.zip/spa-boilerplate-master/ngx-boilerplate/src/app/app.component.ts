import { Component, AfterViewChecked, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { NxEpacParamsService, NxEpacResizeService, NxEpacNavigationObject } from '@allianz/epac';
import { TranslateService, NxPersistenceService, StorageType } from '@allianz/core';
import { environment } from '../environments/environment';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewChecked {

  private urlHelp = `${environment.base_url}/rws-bff-boilerplate/api/application-header-help`;
  private urlUma = `${environment.base_url}/rws-bff-boilerplate/api/urls/uma`;
  private baseUrlApps = '';

  private navigationObject: NxEpacNavigationObject;
  private nxActive: string;
  public translations;
  private language;

  constructor(
    private router: Router,
    private params: NxEpacParamsService,
    private resizeService: NxEpacResizeService,
    private translate: TranslateService,
    private persistence: NxPersistenceService,
    private http: HttpClient
  ) {
    if (environment.base_url.indexOf('localhost') > 0) {
      this.baseUrlApps = 'https://wwwd.es.intrallianz.com';
    }
  }

  ngOnInit(): void {
    this.translate.get(['Header.Football',
                        'Header.Classification',
                        'Header.Team',
                        'Header.Private',
                        'Header.Help',
                        'Header.Print',
                        'Header.Applications'])
      .subscribe((res: string) => {
        this.translations = res;
        this.navigationObject = {
          routes: [{
            id: '1',
            name: this.translations['Header.Football'],
            children: [{
              id: '11',
              name: this.translations['Header.Classification'],
              routerLink: 'football/classification'
            }, {
              id: '12',
              name: this.translations['Header.Team'],
              routerLink: '/football/team'
            }]
          },
          {
            id: '2',
            name: this.translations['Header.Private'],
            routerLink: '/private'
          },
          {
            id: '3',
            name: this.translations['Header.Applications'],
            children: [{
              id: '31',
              name: 'UMA',
              routerLink: ''
            }]
          }]
        };
      });

    this.nxActive = '11';
  }

  calculateHeight(): any {
    const height = Math.max(document.body.scrollHeight,
      document.body.offsetHeight,
      document.body.clientHeight,
      document.documentElement.clientHeight,
      document.documentElement.scrollHeight,
      document.documentElement.offsetHeight);
    return height;
  }

  ngAfterViewChecked() {
    const height = this.calculateHeight();
    let height2;
    if (height !== height2) {
      this.resizeService.resizeIframe();
      height2 = this.calculateHeight();
    }
  }

  nxLinkClicked(event) {
    if (event === '31') {
      this.http.get(this.urlUma)
        .subscribe( res => {
          window.open(this.baseUrlApps + res['data']);
      });
    }
  }
}
