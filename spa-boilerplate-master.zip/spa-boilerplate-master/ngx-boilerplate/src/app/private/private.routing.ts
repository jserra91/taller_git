// General Directorate of Security
import { Routes, RouterModule } from '@angular/router';

import { PrivateComponent } from './private.component';
import { ModuleWithProviders } from '@angular/core';

import { AuthGuardService } from '../auth-guard.service';

export const routes: Routes = [
  {
    path: '',
    component: PrivateComponent,
    canActivate: [AuthGuardService],
    children: [
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', component: PrivateComponent }
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
