import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { routing } from './private.routing';
import { PrivateComponent } from './private.component';

import { NxCoreModule } from '@allianz/core';

import { NxDropdownModule, NxButtonModule } from '@allianz/ngx-ndbx';
import { NxInputModule } from '@allianz/ngx-ndbx/input';
import { NxFormfieldModule } from '@allianz/ngx-ndbx/formfield';
import { NxGridModule } from '@allianz/ngx-ndbx/grid';

import { NxEpacDataTableModule } from '@allianz/epac';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    routing,
    NxCoreModule,
    NxButtonModule,
    NxFormfieldModule,
    NxDropdownModule,
    NxInputModule,
    NxGridModule,
    NxEpacDataTableModule
  ],
  declarations: [PrivateComponent]
})
export class PrivateModule { }
