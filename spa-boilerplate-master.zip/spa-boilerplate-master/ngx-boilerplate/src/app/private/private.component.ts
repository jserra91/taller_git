import { TranslateService } from '@allianz/core';
import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-public',
  templateUrl: './private.component.html',
  styleUrls: ['./private.component.scss']
})

export class PrivateComponent implements OnInit {

  constructor(private router: Router) { }

  public logged = true;

  ngOnInit() { }

  logout() {
    sessionStorage.removeItem('login');
    this.logged = false;
    this.router.navigate(['/football/login']);
  }

}
