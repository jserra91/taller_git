import { TranslateService } from '@allianz/core';
import { Component, OnInit } from '@angular/core';
import { ClassificationService } from '../../../shared/services/classification.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {

  public logged = false;

  constructor(private router: Router) { }

  ngOnInit() { }

    login() {
      sessionStorage.setItem('login', 'loginok');
      this.logged = true;
      this.router.navigate(['/private']);
    }

}
