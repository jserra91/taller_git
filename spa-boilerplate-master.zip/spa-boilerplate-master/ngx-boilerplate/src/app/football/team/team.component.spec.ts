import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { DebugElement } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';

import { InformationComponent } from '../../../shared/components/information/information.component';
import { TeamComponent } from './team.component';
import { TeamService } from '../../../shared/services/team.service';

import { NxDropdownModule, NxButtonModule, NxCheckboxModule,
 NxRadioModule, NxMessageModule } from '@allianz/ngx-ndbx';
import { NxInputModule } from '@allianz/ngx-ndbx/input';
import { NxFormfieldModule } from '@allianz/ngx-ndbx/formfield';
import { NxGridModule } from '@allianz/ngx-ndbx/grid';
import { NxDatefieldModule, NxDatepickerIntl } from '@allianz/ngx-ndbx/datefield';
import { NxMomentDateModule } from '@allianz/ngx-ndbx/moment-date-adapter';

// Core
import { NxCoreModule } from '@allianz/core';

class MockTeamService {
    createTeam(team: any) {
        return of({success: true});
    }
}

describe('TeamComponent', () => {
  let component: TeamComponent;
  let fixture: ComponentFixture<TeamComponent>;
  let el: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TeamComponent,
        InformationComponent
      ],
      imports: [
        NxCoreModule.forRoot(),
        FormsModule,
        HttpClientModule,
        NxButtonModule,
        NxFormfieldModule,
        NxDropdownModule,
        NxInputModule,
        NxGridModule,
        NxCheckboxModule,
        NxRadioModule,
        NxMessageModule,
        NxDatefieldModule,
        NxMomentDateModule
      ],
      providers: [
        {provide: TeamService, useClass: MockTeamService}
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamComponent);
    component = fixture.componentInstance;
    el = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
