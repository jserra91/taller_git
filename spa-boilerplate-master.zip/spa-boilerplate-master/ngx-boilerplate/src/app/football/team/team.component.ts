import { Component, OnInit, Inject } from '@angular/core';
import { TeamService } from '../../../shared/services/team.service';
import { TeamDTO } from '../../../shared/interfaces/team';

import { NX_DATE_LOCALE, NxDateAdapter } from '@allianz/ngx-ndbx/datefield';

import { Moment } from 'moment';


@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.scss']
})
export class TeamComponent implements OnInit {

  public name: string;
  public description: string;
  public foundationDateMoment: Moment;
  public foundationDate: number;
  public color: string;
  public stadium: boolean;
  public fans: number;
  public grass: boolean;
  public showMessage: boolean;

  public displayFormat: string;

  constructor( private teamService: TeamService, public nxDateAdapter: NxDateAdapter<Moment>,
    @Inject(NX_DATE_LOCALE) public nxDateLocale: string ) {
    this.color = '#DCDCDC';
    this.fans = 0;
    this.showMessage = false;
    this.displayFormat = 'DD/MM/YYYY';
  }

  cleanForm() {
    this.name = '';
    this.description = '';
    this.color = '';
    this.stadium = false;
    this.fans = 0;
    this.grass = false;
  }

  ngOnInit() {
    this.nxDateAdapter.setLocale(navigator.language);
  }

  handleSubmit(form: TeamDTO, isValid: boolean) {
    if (isValid) {
      console.log(form);
      form.foundationDate = this.foundationDateMoment.valueOf();
      this.teamService.createTeam(form).subscribe((response) => {
        if (response.success) {
          this.showMessage = true;
          setTimeout(() => {
            this.showMessage = false;
          }, 2000);
          this.cleanForm();
        }
      });
    }
  }
}
