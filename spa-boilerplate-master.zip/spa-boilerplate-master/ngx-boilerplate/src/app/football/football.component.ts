import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-football',
  templateUrl: './football.component.html',
  styleUrls: ['./football.component.scss']
})
export class FootballComponent implements OnInit {

  constructor() {}

  ngOnInit() { }
}
