import { TranslateService } from '@allianz/core';
import { Component, OnInit } from '@angular/core';
import { ClassificationService } from '../../../shared/services/classification.service';

@Component({
  selector: 'app-classification',
  templateUrl: './classification.component.html',
  styleUrls: ['./classification.component.scss']
})

export class ClassificationComponent implements OnInit {

  tableColumns: any[];
  tableData: any[];
  classificationData: any[];
  perPage: number;
  totalElements: number;

  constructor(
    private classificationService: ClassificationService,
    private translate: TranslateService
  ) {
    this.perPage = 5;
    this.tableColumns = [
      { title: 'Classification', key: 'classification', type: 'number', sortable: true },
      { title: 'Name', key: 'name', type: 'string', sortable: false },
      { title: 'PJ', key: 'pj', type: 'number', sortable: false },
      { title: 'PG', key: 'pg', type: 'number', sortable: false },
      { title: 'PE', key: 'pe', type: 'number', sortable: false },
      { title: 'PP', key: 'pp', type: 'number', sortable: false },
      { title: 'GF', key: 'gf', type: 'number', sortable: false },
      { title: 'GC', key: 'gc', type: 'number', sortable: false },
      { title: 'Ptos', key: 'ptos', type: 'number', sortable: true },
    ];
    this.tableData = [];
  }

  ngOnInit() {
    this.classificationService.getAll().subscribe((response) => {
      this.classificationData = response.data;
      this.setDataTable(1);
    });
  }

  setPage(page: number) {
    this.setDataTable(page);
  }

  setPerPage(number: number) {
    this.perPage = number;
    this.setPage(1);
  }

  setDataTable(page: number) {
    page--;
    this.totalElements = this.classificationData.length;
    const start = page * this.perPage;
    const end = Math.min((start + this.perPage), this.totalElements);
    this.tableData = [];
    for (let i = start; i < end; i++) {
      this.tableData.push(this.classificationData[i]);
    }
  }
}
