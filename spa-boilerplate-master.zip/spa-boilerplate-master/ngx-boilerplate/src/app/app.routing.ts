import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';


export const routes: Routes = [
  { path: '', redirectTo: `football/classification`, pathMatch: 'full'},
  { path: 'football', loadChildren: 'app/football/football.module#FootballModule', },
  { path: 'private', loadChildren: 'app/private/private.module#PrivateModule' }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes, { useHash: false });
