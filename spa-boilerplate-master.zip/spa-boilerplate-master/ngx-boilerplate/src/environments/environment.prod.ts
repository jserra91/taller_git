export const environment = {
  production: true,
  base_url: '', // Empty for production
  domain: '' // Empty for production
};
