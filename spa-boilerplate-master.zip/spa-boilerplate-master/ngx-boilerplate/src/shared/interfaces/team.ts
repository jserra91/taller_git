export class TeamDTO {
    name: string;
    description: string;
    foundationDate: number;
    color: string;
    stadium: boolean;
    fans: number;
    grass: boolean;
}
