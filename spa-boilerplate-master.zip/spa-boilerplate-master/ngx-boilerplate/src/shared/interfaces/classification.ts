export class ClassificationDTO {
    classification: number;
    name: string;
    pj: number;
    pg: number;
    pe: number;
    pp: number;
    gf: number;
    gc: number;
    ptos: number;
}
