import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { NxCoreModule } from '@allianz/core';
import {
  NxButtonModule,
  NxDropdownModule,
  NxRadioToggleModule,
  NxHeadlineModule,
  NxRadioModule,
} from '@allianz/ngx-ndbx';
import { NxInputModule } from '@allianz/ngx-ndbx/input';
import { NxFormfieldModule } from '@allianz/ngx-ndbx/formfield';
import { NxGridModule } from '@allianz/ngx-ndbx/grid';
import { NxIconModule } from '@allianz/ngx-ndbx/icon';

import { OverlayModule } from '@angular/cdk/overlay';

import { InformationComponent } from './components/information/information.component';
import { ClassificationService } from './services/classification.service';

@NgModule({
  declarations: [ InformationComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NxButtonModule,
    NxDropdownModule,
    NxFormfieldModule,
    OverlayModule,
    NxInputModule,
    NxGridModule,
    NxHeadlineModule,
    NxRadioModule,
    NxRadioToggleModule,
    NxIconModule,
    NxCoreModule
  ],
  providers: [ClassificationService],
  exports: [InformationComponent]
})

export class SharedModule {
  static forRoot(): ModuleWithProviders {
      return {
          ngModule: SharedModule
      };
  }
}
