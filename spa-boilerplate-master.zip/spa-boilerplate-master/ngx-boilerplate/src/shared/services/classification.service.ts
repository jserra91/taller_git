import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { ResponseModel } from '../interfaces/responseModel';
import { ClassificationDTO } from '../interfaces/classification';
import { environment } from '../../environments/environment';

@Injectable()
export class ClassificationService {

  private url = `${environment.base_url}/rws-bff-boilerplate/api/football/classification`;

  constructor(private http: HttpClient) { }

  getAll(): Observable<ResponseModel<ClassificationDTO>> {
    return this.http.get<ResponseModel<ClassificationDTO>>(this.url);
  }
}
