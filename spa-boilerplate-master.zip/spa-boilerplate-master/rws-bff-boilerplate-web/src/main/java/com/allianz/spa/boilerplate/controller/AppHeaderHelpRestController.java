package com.allianz.spa.boilerplate.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.rest.support.model.RESTResponseBean;
import com.allianz.rws.frontend.core.components.model.dto.AppHeaderHelpDTO;
import com.allianz.rws.frontend.core.components.service.AppHeaderHelpRestService;

/**
 * Handles requests for the ApplicationHeaderHelp service.
 */
@RestController
public class AppHeaderHelpRestController implements AppHeaderHelpRestApi {

	private static Logger logger = LoggerFactory.getLogger(AppHeaderHelpRestController.class);

	@Autowired
	private AppHeaderHelpRestService appHeaderHelpService;

	@Override
	public @ResponseBody ResponseEntity<?> getAppHeaderHelp(
			@RequestParam(value = "pageID", required = false) String pageID,
			@RequestHeader HttpHeaders headers) {

		logger.info("Init getAppHeaderHelp");

		AppHeaderHelpDTO appHeaderHelpDTO = appHeaderHelpService
				.getApplicationHelp(pageID, "ngx-boilerplate");


		return RESTResponseBean.builder().success(true).data(appHeaderHelpDTO).status(HttpStatus.OK)
				.buildResponseEntity();
	}
}
