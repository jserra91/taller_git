package com.allianz.spa.boilerplate.model.dto;

public class OauthDTO {

	private String accessToken;
	
	private String refreshToken;
	
	private String companyId;
	
	
	public OauthDTO() {
	}


	public String getAccessToken() {
		return accessToken;
	}


	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}


	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}


	public String getCompanyId() {
		return companyId;
	}


	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
}
