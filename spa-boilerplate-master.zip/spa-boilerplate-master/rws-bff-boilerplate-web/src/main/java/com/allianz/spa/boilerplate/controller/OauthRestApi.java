package com.allianz.spa.boilerplate.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.allianz.spa.boilerplate.model.dto.OauthDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@Api(tags = {"oauth"})
@RequestMapping(path = { "/api/oauth", "/api/v1/oauth" }, produces = {MediaType.APPLICATION_JSON_VALUE} )
public interface OauthRestApi {
	
	@ApiOperation(
			value = "Refresh Token", 
		    notes = "Refresh Token")
	  	@ApiResponses(
	  		value = { 
	  			@ApiResponse(code = 500, message = "Internal server error"),
	  		})
	@PostMapping(path = "refresh-token")
	ResponseEntity<?> refreshToken(OauthDTO oauth);
	
	@ApiOperation(
			value = "Public login", 
		    notes = "Public login")
	  	@ApiResponses(
	  		value = { 
	  			@ApiResponse(code = 500, message = "Internal server error"),
	  		})
	@PostMapping(path = "public-login")
	ResponseEntity<?> publicLogin(OauthDTO oauth);	
}
