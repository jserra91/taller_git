package com.allianz.spa.boilerplate.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.rest.support.model.RESTResponseBean;
import com.allianz.spa.boilerplate.model.dto.ClassificationDTO;
import com.allianz.spa.boilerplate.model.dto.TeamDTO;

/**
 * Handles requests for the football classification.
 */
@RestController
public class FootballRestController implements FootballRestApi {

	private static Logger logger = LoggerFactory.getLogger(FootballRestController.class);

	@Override
	public @ResponseBody ResponseEntity<?> getClassification(@RequestHeader HttpHeaders headers) {

		logger.info("Init getTeams");

		List<ClassificationDTO> list = new ArrayList<>();
		ClassificationDTO classificationDTO = new ClassificationDTO();
		classificationDTO.setName("User Interface");
		classificationDTO.setClassification(1);
		classificationDTO.setPj(30);
		classificationDTO.setPg(23);
		classificationDTO.setPe(7);
		classificationDTO.setPp(0);
		classificationDTO.setGf(100);
		classificationDTO.setGc(22);
		classificationDTO.setPtos(76);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("Platform Arquitecture & Innovation");
		classificationDTO.setClassification(2);
		classificationDTO.setPj(30);
		classificationDTO.setPg(21);
		classificationDTO.setPe(7);
		classificationDTO.setPp(2);
		classificationDTO.setGf(97);
		classificationDTO.setGc(26);
		classificationDTO.setPtos(68);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("QA & Testing");
		classificationDTO.setClassification(3);
		classificationDTO.setPj(30);
		classificationDTO.setPg(18);
		classificationDTO.setPe(7);
		classificationDTO.setPp(5);
		classificationDTO.setGf(90);
		classificationDTO.setGc(20);
		classificationDTO.setPtos(66);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("IT Information security");
		classificationDTO.setClassification(4);
		classificationDTO.setPj(30);
		classificationDTO.setPg(16);
		classificationDTO.setPe(9);
		classificationDTO.setPp(5);
		classificationDTO.setGf(80);
		classificationDTO.setGc(35);
		classificationDTO.setPtos(60);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("Document Management");
		classificationDTO.setClassification(5);
		classificationDTO.setPj(30);
		classificationDTO.setPg(14);
		classificationDTO.setPe(9);
		classificationDTO.setPp(7);
		classificationDTO.setGf(77);
		classificationDTO.setGc(41);
		classificationDTO.setPtos(56);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("Network & Servers");
		classificationDTO.setClassification(6);
		classificationDTO.setPj(30);
		classificationDTO.setPg(13);
		classificationDTO.setPe(9);
		classificationDTO.setPp(8);
		classificationDTO.setGf(78);
		classificationDTO.setGc(47);
		classificationDTO.setPtos(54);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("Application Servers");
		classificationDTO.setClassification(7);
		classificationDTO.setPj(30);
		classificationDTO.setPg(12);
		classificationDTO.setPe(10);
		classificationDTO.setPp(8);
		classificationDTO.setGf(77);
		classificationDTO.setGc(52);
		classificationDTO.setPtos(51);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("Clients MM & Querys");
		classificationDTO.setClassification(8);
		classificationDTO.setPj(30);
		classificationDTO.setPg(11);
		classificationDTO.setPe(9);
		classificationDTO.setPp(10);
		classificationDTO.setGf(70);
		classificationDTO.setGc(45);
		classificationDTO.setPtos(50);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("Go! & File Management");
		classificationDTO.setClassification(9);
		classificationDTO.setPj(30);
		classificationDTO.setPg(10);
		classificationDTO.setPe(9);
		classificationDTO.setPp(11);
		classificationDTO.setGf(70);
		classificationDTO.setGc(71);
		classificationDTO.setPtos(48);
		list.add(classificationDTO);
		
		classificationDTO = new ClassificationDTO();
		classificationDTO.setName("Accounting");
		classificationDTO.setClassification(10);
		classificationDTO.setPj(30);
		classificationDTO.setPg(9);
		classificationDTO.setPe(9);
		classificationDTO.setPp(12);
		classificationDTO.setGf(62);
		classificationDTO.setGc(60);
		classificationDTO.setPtos(40);
		list.add(classificationDTO);

		return RESTResponseBean.builder().success(true).data(list).status(HttpStatus.OK).buildResponseEntity();
	}

	@Override
	public ResponseEntity<?> createTeam(TeamDTO teamDTO) {

		return RESTResponseBean.builder().success(true).status(HttpStatus.OK).buildResponseEntity();
	}

}
