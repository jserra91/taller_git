package com.allianz.spa.boilerplate.configuration;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.rest.support.auto.service.RWSDefaultExceptionHandler;

@ControllerAdvice  
@RestController  
public class GlobalDefaultExceptionHandler extends RWSDefaultExceptionHandler  {
	
}