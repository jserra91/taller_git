package com.allianz.spa.boilerplate.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@Api(tags = {"async-validators"})
@RequestMapping(path = { "/api/async-validators", "/api/v1/async-validators" }, produces = {MediaType.APPLICATION_JSON_VALUE} )
public interface AsyncValidatorRestApi {
	
	@ApiOperation(
			value = "AsyncValidator example", 
		    notes = "AsyncValidator example"
		    )
	  	@ApiResponses(
	  		value = { 
	  			@ApiResponse(code = 500, message = "Internal server error"),
	  			@ApiResponse(code = 404, message = "Service not found") 
	  		})
		@ApiImplicitParams({
			@ApiImplicitParam(name = "data", value = "policyNumber", required = true, dataType = "string", paramType = "query"),
		})
	@RequestMapping(method = RequestMethod.GET)
	ResponseEntity<?> isPolicyValid(
			@RequestParam(value = "data", required = true) String policyNumber,
			@RequestHeader HttpHeaders headers);	
}