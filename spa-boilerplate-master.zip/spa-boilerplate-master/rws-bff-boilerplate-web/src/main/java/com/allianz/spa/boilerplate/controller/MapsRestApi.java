package com.allianz.spa.boilerplate.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@Api(tags = {"maps"})
@RequestMapping(path = { "/api/maps", "/api/v1/maps" }, produces = {MediaType.APPLICATION_JSON_VALUE} )
public interface MapsRestApi {
	
	@ApiOperation(
			value = "Get google map key", 
		    notes = "get google map key"
		    )
  	@ApiResponses(
  		value = { 
  			@ApiResponse(code = 500, message = "Internal server error"),
  			@ApiResponse(code = 404, message = "Service not found") 
  		})
	@GetMapping(path = "google-maps-key")
	ResponseEntity<?> getGoogleMapsKey();	
}