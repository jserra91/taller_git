package com.allianz.spa.boilerplate.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.allianz.rest.support.util.AllianzRestTemplate;

@Configuration
public class BeansConfig {

    @Bean(name = "allianzRestTemplate")
    public AllianzRestTemplate getAllianzRestTemplate() {
    	return new AllianzRestTemplate();
    }	

}
