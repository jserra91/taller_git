package com.allianz.spa.boilerplate.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.rest.support.model.RESTResponseBean;
import com.allianz.rws.frontend.core.components.model.dto.GoogleMapsKeyDTO;
import com.allianz.rws.frontend.core.components.service.MapsRestService;

/**
 * Handles requests for the Maps service.
 */
@RestController
public class MapsRestController implements MapsRestApi {

	private static Logger logger = LoggerFactory.getLogger(MapsRestController.class);

	@Autowired
	private MapsRestService mapsRestService;

	@Override
	public @ResponseBody ResponseEntity<?> getGoogleMapsKey() {

		logger.info("Init getGoogleMapsKey");

		GoogleMapsKeyDTO googleMapsKeyDTO = mapsRestService
				.getGoogleMapsKey();


		return RESTResponseBean.builder().success(true).data(googleMapsKeyDTO).status(HttpStatus.OK)
				.buildResponseEntity();
	}
}
