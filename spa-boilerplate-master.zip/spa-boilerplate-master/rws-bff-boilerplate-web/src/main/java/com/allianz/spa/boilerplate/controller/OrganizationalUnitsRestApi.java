package com.allianz.spa.boilerplate.controller;


import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags = {"organizational-units"})
@RequestMapping(path = { "/api/organizational-units", "/api/v1/organizational-units"}, produces = {MediaType.APPLICATION_JSON_VALUE} )
		
public interface OrganizationalUnitsRestApi {
		
		@ApiOperation(
				value = "Find OrganizationalUnits", 
			    notes = "Method for request the OrganizationalUnits"
			    )
		  	@ApiResponses(
		  		value = { 
		  			@ApiResponse(code = 500, message = "Internal server error"),
		  			@ApiResponse(code = 404, message = "No results found"),
		  		})
			@ApiImplicitParams({

			})
		@RequestMapping(method = RequestMethod.GET)
		ResponseEntity<com.allianz.rws.frontend.core.components.model.dto.OrganizationalUnitsDTO> getOrganizationalUnits();
}