package com.allianz.spa.boilerplate.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.rest.support.model.RESTResponseBean;
import com.allianz.spa.boilerplate.model.dto.AsyncValidatorDTO;

/**
 * Handles requests for the AsyncValidators service.
 */
@RestController
public class AsyncValidatorsRestController implements AsyncValidatorRestApi {

	private static Logger logger = LoggerFactory.getLogger(AsyncValidatorsRestController.class);

	@Override
	public @ResponseBody ResponseEntity<?> isPolicyValid(@RequestParam(value = "data", required = false) String policyNumber,
			@RequestHeader HttpHeaders headers) {

		logger.info("Init isPolicyValid");

		AsyncValidatorDTO asyncValidatorDTO = new AsyncValidatorDTO();
		if (policyNumber.contains("9")) {
			asyncValidatorDTO.setAsyncError("notExists");
		} else if (policyNumber.contains("123")) {
			asyncValidatorDTO.setAsyncError("diferentAgent");
		} else {
			asyncValidatorDTO.setAsyncError("");
		}

		return RESTResponseBean.builder().success(true).data(asyncValidatorDTO).status(HttpStatus.OK)
				.buildResponseEntity();
	}
}
