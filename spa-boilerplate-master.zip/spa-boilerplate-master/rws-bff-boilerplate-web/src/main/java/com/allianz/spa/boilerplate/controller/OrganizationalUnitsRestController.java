package com.allianz.spa.boilerplate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.rest.support.model.RESTResponseBean;
import com.allianz.rws.frontend.core.components.service.OrganizationalUnitsRestService;

/**
 * Request to receive the OrganizationalUnits list.
 */
@RestController
public class OrganizationalUnitsRestController implements OrganizationalUnitsRestApi {

	@Autowired
	private OrganizationalUnitsRestService organizationalUnitsService;

	@Override
	public @ResponseBody ResponseEntity<com.allianz.rws.frontend.core.components.model.dto.OrganizationalUnitsDTO> getOrganizationalUnits() {

		List<com.allianz.rws.frontend.core.components.model.dto.OrganizationalUnitsDTO> organizationalUnitsList = organizationalUnitsService
				.getOrganizationalUnits();

		return RESTResponseBean.builder().success(true).data(organizationalUnitsList).status(HttpStatus.OK)
				.buildResponseEntity();
	}
}
