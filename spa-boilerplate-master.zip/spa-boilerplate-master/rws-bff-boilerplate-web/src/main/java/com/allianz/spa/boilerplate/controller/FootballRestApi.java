package com.allianz.spa.boilerplate.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import com.allianz.spa.boilerplate.model.dto.TeamDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@Api(tags = {"football"})
@RequestMapping(path = { "/api/football", "/api/v1/football" }, produces = {MediaType.APPLICATION_JSON_VALUE} )
public interface FootballRestApi {
	
	@ApiOperation(
			value = "Get classification", 
		    notes = "Get classification"
		    )
	  	@ApiResponses(
	  		value = { 
	  			@ApiResponse(code = 500, message = "Internal server error"),
	  			@ApiResponse(code = 404, message = "Service not found") 
	  		})
		@ApiImplicitParams({
		})
	@GetMapping(path="/classification")
	ResponseEntity<?> getClassification(
			@RequestHeader HttpHeaders headers);	
	
	
	@ApiOperation(value = "Create team", notes = "Create team")
	@ApiResponses(value = {
			@ApiResponse(code = 500, message = "Internal server error"),
			@ApiResponse(code = 404, message = "Service not found") })
	@PostMapping(path="/teams")
	ResponseEntity<?> createTeam(TeamDTO teamDTO);

}