package com.allianz.spa.boilerplate.service;

public interface ConfigurationService {

	String getClientAppResourceId();

}
