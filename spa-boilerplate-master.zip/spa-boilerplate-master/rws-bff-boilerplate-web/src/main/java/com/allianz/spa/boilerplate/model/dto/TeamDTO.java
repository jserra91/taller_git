package com.allianz.spa.boilerplate.model.dto;

public class TeamDTO {

	private String name;
	
	private String description;
	
	private Integer foundationDate;
	
	private String color;
	
	private boolean stadium;
	
	private Integer fans;
	
	private boolean grass;
	
	public TeamDTO() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getFoundationDate() {
		return foundationDate;
	}

	public void setFoundationDate(Integer foundationDate) {
		this.foundationDate = foundationDate;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isStadium() {
		return stadium;
	}

	public void setStadium(boolean stadium) {
		this.stadium = stadium;
	}

	public Integer getFans() {
		return fans;
	}

	public void setFans(Integer fans) {
		this.fans = fans;
	}

	public boolean isGrass() {
		return grass;
	}

	public void setGrass(boolean grass) {
		this.grass = grass;
	}

}
