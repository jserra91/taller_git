package com.allianz.spa.boilerplate.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.rest.support.model.RESTResponseBean;
import com.allianz.rest.support.util.AllianzCompanyConverter;
import com.allianz.rest.support.util.AllianzContextHolder;
import com.allianz.rws.gateway.model.dto.ChecksumDTO;
import com.allianz.rws.gateway.service.ChecksumRestService;

/**
 * Handles requests for the UrlExternalApps service.
 */
@RestController
public class UrlExternalAppsRestController implements UrlExternalAppsRestApi {

	private static Logger logger = LoggerFactory.getLogger(UrlExternalAppsRestController.class);

	
	@Autowired
	private ChecksumRestService checksumRestService;


	@Override
	public @ResponseBody ResponseEntity<?> getUrlUma() {

		logger.info("Init getUrlUma");

		Map<String, String> map = new HashMap<String, String>();
		String userId = AllianzContextHolder.getContext().getUserId();
		String companyId = AllianzContextHolder.getContext().getCompanyId();
		String codCia = String.valueOf(AllianzCompanyConverter.fromCod3ToId(companyId));
		map.put("uid", userId);
		map.put("tipo", "A");
		map.put("codCia", codCia);
		map.put("action", "start");

		ChecksumDTO result = checksumRestService.generateChecksum(map);

		
		String url = "/drgu02/SEAServlet?action=start&uid="+userId+"&tipo=A&codCia="+codCia+"&timestamp="+result.getTimestamp()+"&checksum="+result.getChecksum();


		return RESTResponseBean.builder().success(true).data(url).status(HttpStatus.OK)
				.buildResponseEntity();
	}
	
}
