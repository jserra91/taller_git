package com.allianz.spa.boilerplate.model.dto;

public class AsyncValidatorDTO {

	private String asyncError;
	
	
	public AsyncValidatorDTO() {
	}


	public String getAsyncError() {
		return asyncError;
	}


	public void setAsyncError(String asyncError) {
		this.asyncError = asyncError;
	}

}
