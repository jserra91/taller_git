package com.allianz.spa.boilerplate.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.oauth2.common.util.JsonParser;
import org.springframework.security.oauth2.common.util.JsonParserFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allianz.rest.support.auto.service.OAuthLoginService;
import com.allianz.rest.support.model.ErrorBean;
import com.allianz.rest.support.model.LoginBean;
import com.allianz.rest.support.model.OAuthTokensBean;
import com.allianz.rest.support.model.RESTResponseBean;
import com.allianz.rest.support.util.AllianzContextHolder;
import com.allianz.spa.boilerplate.model.dto.OauthDTO;

/**
 * Handles requests for the OAuth service.
 */
@RestController
public class OAuthRestController implements OauthRestApi {

	private static Logger logger = LoggerFactory.getLogger(OAuthRestController.class);

	@Autowired
	private OAuthLoginService loginService;

	@Override
	public @ResponseBody ResponseEntity<?> refreshToken(@RequestBody OauthDTO oauth) {

		logger.info("Init refreshToken");

		OauthDTO oauthRes = new OauthDTO();
		try {
			Map<String, Object> jwtDetail = null;
			Jwt decodeJwt = JwtHelper.decode(oauth.getRefreshToken());
			String jwtInfo = decodeJwt.getClaims();
			if (jwtInfo != null) {
				JsonParser objectMapper = JsonParserFactory.create();
				jwtDetail = objectMapper.parseMap(jwtInfo);
			}
	
			String clientId = (String) jwtDetail.get("client_id");
			String companyId = (String) jwtDetail.get("epac-company-id");
			String clientSecret = "f8739f23-61ea-4df7-b70b-853e9b6eb0f3";
			if (clientId.equals("INTERNET")) {
				clientSecret = "f8739f23-61ea-4df7-b70b-853e9b6eb0f3";
			} else if (clientId.equals("TEST-VOLATILE")) {
				clientSecret = "r152430c-bu90-i1e1-9oc3-c4e64d62c636";
			}
	
			AllianzContextHolder.getContext().setCompanyId(companyId);

			OAuthTokensBean oAuthTokensBean = loginService.refresh(clientId, clientSecret, oauth.getRefreshToken());
			oauthRes.setAccessToken(oAuthTokensBean.getAccessToken());
			
		} catch (Exception e) {
			ErrorBean errorBean = new ErrorBean();
			errorBean.setCode("401");
			errorBean.setMessage("Unauthorized");
			return RESTResponseBean.builder().success(false).status(HttpStatus.BAD_REQUEST).error(errorBean)
					.buildResponseEntity();
		}

		return RESTResponseBean.builder().success(true).status(HttpStatus.OK).data(oauthRes).buildResponseEntity();

	}

	@Override
	public @ResponseBody ResponseEntity<?> publicLogin(@RequestBody OauthDTO oauth) {

		logger.info("Init public login");

		AllianzContextHolder.getContext().setCompanyId(oauth.getCompanyId());

		LoginBean loginBean = new LoginBean();
		loginBean.setClientId("INTRANET");
		loginBean.setClientSecret("f8739f23-61ea-4df7-b70b-853e9b6eb0f3");
		loginBean.setGrantType("client_credentials");

		OauthDTO oauthRes = new OauthDTO();
		try {
			OAuthTokensBean oAuthTokensBean = loginService.login(loginBean);
			oauthRes.setAccessToken(oAuthTokensBean.getAccessToken());
		} catch (Exception e) {
			ErrorBean errorBean = new ErrorBean();
			errorBean.setCode("401");
			errorBean.setMessage("Unauthorized");
			return RESTResponseBean.builder().success(false).status(HttpStatus.BAD_REQUEST).error(errorBean)
					.buildResponseEntity();
		}

		return RESTResponseBean.builder().success(true).status(HttpStatus.OK).data(oauthRes).buildResponseEntity();

	}
}
